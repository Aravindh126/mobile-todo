import 'package:flutter/material.dart';
import '../models/task.dart';
import '../widgets/task_dialog.dart';

class HomeScreen extends StatefulWidget {
  final String userName;
  const HomeScreen({super.key, required this.userName});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final List<Task> _tasks = [];

  void _addTask() {
    showDialog(
      context: context,
      builder: (_) => TaskDialog(onSave: (task) {
        setState(() => _tasks.add(task));
      }),
    );
  }

  void _deleteTask(int index) {
    setState(() => _tasks.removeAt(index));
  }

  void _toggleComplete(int index) {
    setState(() => _tasks[index].isComplete = !_tasks[index].isComplete);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Welcome, \${widget.userName}"),
      ),
      body: _tasks.isEmpty
          ? const Center(child: Text("No tasks added yet"))
          : ListView.builder(
              itemCount: _tasks.length,
              itemBuilder: (_, i) {
                final task = _tasks[i];
                return Dismissible(
                  key: Key(task.title + i.toString()),
                  direction: DismissDirection.endToStart,
                  onDismissed: (_) => _deleteTask(i),
                  background: Container(
                    color: Colors.red,
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: const Icon(Icons.delete, color: Colors.white),
                  ),
                  child: ListTile(
                    title: Text(
                      task.title,
                      style: TextStyle(
                        decoration:
                            task.isComplete ? TextDecoration.lineThrough : null,
                      ),
                    ),
                    subtitle: Text(
                        "\${task.description}\nDue: \${task.dueDate.toLocal().toString().split(' ')[0]}"),
                    isThreeLine: true,
                    trailing: Checkbox(
                      value: task.isComplete,
                      onChanged: (_) => _toggleComplete(i),
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addTask,
        child: const Icon(Icons.add),
      ),
    );
  }
}
