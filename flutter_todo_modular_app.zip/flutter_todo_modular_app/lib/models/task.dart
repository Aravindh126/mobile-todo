class Task {
  String title;
  String description;
  DateTime dueDate;
  bool isComplete;

  Task({
    required this.title,
    required this.description,
    required this.dueDate,
    this.isComplete = false,
  });
}
